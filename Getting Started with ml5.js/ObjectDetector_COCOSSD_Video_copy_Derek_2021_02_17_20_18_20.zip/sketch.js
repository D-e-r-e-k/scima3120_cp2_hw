// Copyright (c) 2020 ml5
//
// This software is released under the MIT License.
// https://opensource.org/licenses/MIT

/* ===
ml5 Example
Object Detection using COCOSSD
This example uses a callback pattern to create the classifier
=== */

let video;
let detector;
let detections = [];

function setup() {
  createCanvas(640, 480);
  video = createCapture(VIDEO, function() {
    // Wait for the video to be loaded
    video.size(640, 480);
    video.hide();
    // Models available are 'cocossd', 'yolo'
    detector = ml5.objectDetector('cocossd', modelReady);
  });
}

function gotDetections(error, results) {
  if (error) {
    console.error(error);
  }
  detections = results;
  if(results.length > 1){
     print(results);
  }
  detector.detect(video, gotDetections);
}

function modelReady() {
  detector.detect(video, gotDetections);
}

function draw() {
  for (let i = 0; i < detections.length; i++) {
    if (detections[i].label === "person") {
      background(0);
      fill(255);
      textAlign(CENTER,CENTER);
      text("STOP LOOKING AT ME", width/2, height/2);
      return;
    }
  }
  image(video, 0, 0);

  for (let i = 0; i < detections.length; i++) {
    let object = detections[i];
    stroke(0, 255, 0);
    strokeWeight(4);
    noFill();
    rect(object.x, object.y, object.width, object.height);
    noStroke();
    fill(255);
    textSize(24);
    text(object.label, object.x + 10, object.y + 24);
  }
}
